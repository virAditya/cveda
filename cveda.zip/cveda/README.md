# cveda readme
A minimal starter for the cveda project.
