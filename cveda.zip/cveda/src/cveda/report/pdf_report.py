"""
Robust PDF report generator for CVEDA.

Goals
- never fail silently while composing the report
- sanitize feature outputs to remove numpy types pathlib Paths and bytes
- continue rendering when a single feature raises an error
- if full rendering fails attempt to write a minimal fallback PDF
- return the written path on success

Dependencies
- reportlab
- matplotlib
- pillow
- numpy

Install if needed
pip install reportlab matplotlib pillow numpy
"""

from __future__ import annotations

import io
import json
import traceback
from typing import Any, Dict, Optional, List, Tuple
from pathlib import Path
import logging

from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as RLImage, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_CENTER
import matplotlib.pyplot as plt
from PIL import Image
import numpy as np

logger = logging.getLogger(__name__)


# -------------------- helpers --------------------

def _deep_sanitize(obj: Any) -> Any:
    """
    Recursively convert objects to JSON friendly Python types.
    Handles numpy scalars arrays bytes and pathlib Paths and PIL Images.
    Leaves strings ints floats lists dicts as is.
    """
    try:
        if obj is None:
            return None
        if isinstance(obj, (str, int, float, bool)):
            return obj
        if isinstance(obj, Path):
            return str(obj)
        if isinstance(obj, bytes):
            # represent small byte blobs as length
            return {"__bytes__len": len(obj)}
        # numpy
        if isinstance(obj, np.generic):
            return obj.item()
        if isinstance(obj, np.ndarray):
            try:
                return obj.tolist()
            except Exception:
                return str(obj)
        # PIL
        if isinstance(obj, Image.Image):
            try:
                buf = io.BytesIO()
                obj.save(buf, format="JPEG", quality=60)
                return {"__image_bytes__len": buf.tell()}
            except Exception:
                return str(obj)
        if isinstance(obj, dict):
            out = {}
            for k, v in obj.items():
                try:
                    out[str(k)] = _deep_sanitize(v)
                except Exception:
                    out[str(k)] = f"<sanitization error for key {k}>"
            return out
        if isinstance(obj, (list, tuple, set)):
            out = []
            for v in obj:
                try:
                    out.append(_deep_sanitize(v))
                except Exception:
                    out.append("<sanitization error>")
            return out
        # fallback try json
        try:
            json.dumps(obj, default=str)
            return obj
        except Exception:
            return str(obj)
    except Exception:
        return f"<sanitizer failure> {repr(obj)[:200]}"


def _make_thumbnail_bytes(path: str, max_size: Tuple[int, int] = (260, 180)) -> Optional[io.BytesIO]:
    """
    Create a JPEG thumbnail as a bytes buffer. Returns None on failure.
    """
    try:
        with Image.open(path) as im:
            im = im.convert("RGB")
            im.thumbnail(max_size)
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=70)
            buf.seek(0)
            return buf
    except Exception:
        return None


def _plot_bar(labels: List[str], values: List[float], title: str = "") -> Optional[io.BytesIO]:
    try:
        fig, ax = plt.subplots(figsize=(6.5, 2.2))
        ax.bar(range(len(values)), values)
        ax.set_xticks(range(len(values)))
        ax.set_xticklabels(labels, rotation=45, ha="right", fontsize=8)
        ax.set_title(title, fontsize=10)
        plt.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="PNG", dpi=140, bbox_inches="tight")
        plt.close(fig)
        buf.seek(0)
        return buf
    except Exception:
        return None


def _plot_pie(labels: List[str], values: List[float], title: str = "") -> Optional[io.BytesIO]:
    try:
        fig, ax = plt.subplots(figsize=(4.5, 3.0))
        ax.pie(values, labels=labels, autopct="%1.1f%%", startangle=140)
        ax.axis("equal")
        ax.set_title(title, fontsize=10)
        plt.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="PNG", dpi=140, bbox_inches="tight")
        plt.close(fig)
        buf.seek(0)
        return buf
    except Exception:
        return None


def _paragraph(text: str, styles, style_name: str = "Normal") -> Paragraph:
    # small safe wrapper
    return Paragraph(text.replace("\n", "<br/>"), styles[style_name])


# -------------------- rendering --------------------

def _render_cover(story: List[Any], styles, dataset_root: str, meta: Dict[str, Any]):
    story.append(Spacer(1, 8 * mm))
    title = Paragraph("CVEDA Dataset Audit", ParagraphStyle("Title", parent=styles["Title"], alignment=TA_CENTER, fontSize=26))
    story.append(title)
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(f"Dataset root {dataset_root}", styles["Normal"]))
    story.append(Spacer(1, 2 * mm))
    if meta:
        story.append(Paragraph("Run metadata", styles["Heading3"]))
        for k, v in meta.items():
            story.append(Paragraph(f"{k} : {str(v)}", styles["Normal"]))
    story.append(PageBreak())


def _render_executive(story: List[Any], styles, audit: Dict[str, Any]):
    story.append(Paragraph("Executive summary", styles["Heading2"]))
    n_images = len(audit.get("index", {}))
    story.append(Paragraph(f"Images indexed {n_images}", styles["Normal"]))
    checks = audit.get("checks", {})
    if isinstance(checks, dict):
        # show simple table of check statuses
        rows = [["Check", "Status"]]
        for k, v in checks.items():
            status = "ok"
            if isinstance(v, dict) and v.get("status") == "error":
                status = "error"
            rows.append([k, status])
        table = Table(rows, colWidths=[80 * mm, 80 * mm])
        table.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                                   ("BACKGROUND", (0, 0), (-1, 0), colors.whitesmoke)]))
        story.append(table)
    story.append(Spacer(1, 3 * mm))
    story.append(PageBreak())


def _render_feature(story: List[Any], styles, name: str, output: Dict[str, Any], index: Dict[str, Any], sample_thumbs: int = 6):
    story.append(Paragraph(name.replace("_", " ").title(), styles["Heading3"]))
    # sanitized output for human readable display
    safe_out = _deep_sanitize(output or {})
    # short explanation using available description fields if present
    desc = safe_out.get("description") or safe_out.get("explanation") or f"Feature {name} results."
    story.append(_paragraph(desc, styles))
    story.append(Spacer(1, 2 * mm))
    # key takeaways
    story.append(Paragraph("Key findings", styles["Heading4"]))
    # generate textual takeaways from some common patterns
    takeaways = []
    try:
        if isinstance(safe_out, dict):
            if safe_out.get("status") == "error":
                takeaways.append("Feature reported an error during execution")
            if "n_images" in safe_out:
                takeaways.append(f"Images inspected {int(safe_out.get('n_images', 0))}")
            if "sampled_images" in safe_out:
                takeaways.append(f"Sampled images {int(safe_out.get('sampled_images', 0))}")
            if "mean_score" in safe_out:
                takeaways.append(f"Mean score {float(safe_out.get('mean_score')):.3f}")
            # class counts common pattern
            if "counts" in safe_out and isinstance(safe_out["counts"], dict):
                top = sorted(safe_out["counts"].items(), key=lambda x: x[1], reverse=True)[:6]
                takeaways.append("Top classes " + ", ".join(f"{k}:{v}" for k, v in top))
    except Exception:
        takeaways.append("Could not compute automated takeaways for this feature")
    if not takeaways:
        takeaways.append("No automatic takeaways generated for this feature")
    for t in takeaways:
        story.append(Paragraph("• " + t, styles["Normal"]))
    story.append(Spacer(1, 2 * mm))

    # small metrics table try to show some top level scalars
    rows = [["Metric", "Value"]]
    try:
        for k, v in safe_out.items():
            if isinstance(v, (str, int, float)):
                rows.append([str(k), str(v)])
            if len(rows) >= 20:
                break
    except Exception:
        rows.append(["metrics", "unavailable"])
    if len(rows) > 1:
        table = Table(rows, colWidths=[70 * mm, 90 * mm])
        table.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                                   ("BACKGROUND", (0, 0), (-1, 0), colors.whitesmoke)]))
        story.append(table)
        story.append(Spacer(1, 2 * mm))

    # try charts when possible
    try:
        if isinstance(safe_out, dict) and "counts" in safe_out and isinstance(safe_out["counts"], dict):
            labels = list(safe_out["counts"].keys())[:12]
            values = [float(safe_out["counts"][k]) for k in labels]
            buf = _plot_bar(labels, values, title="Top class counts")
            if buf:
                story.append(RLImage(buf, width=160 * mm, height=45 * mm))
                story.append(Spacer(1, 2 * mm))
    except Exception:
        logger.debug("chart rendering failed for feature %s", name, exc_info=True)

    # show thumbnails of examples when possible
    thumbs = []
    try:
        # look for common keys that may contain examples
        for key in ("examples", "samples", "top_blocky_examples", "candidates", "duplicates"):
            if key in output and output[key]:
                candidates = output[key]
                if isinstance(candidates, dict):
                    # maybe mapping class to list
                    for v in candidates.values():
                        if isinstance(v, list):
                            candidates = v
                            break
                if isinstance(candidates, list):
                    for ex in candidates:
                        if len(thumbs) >= sample_thumbs:
                            break
                        if isinstance(ex, dict):
                            fn = ex.get("file") or ex.get("file_name") or ex.get("path")
                        else:
                            fn = ex
                        if not fn:
                            continue
                        # if index has entry attempt to use abs_path
                        rec = index.get(fn)
                        imgp = None
                        if rec and isinstance(rec, dict):
                            imgp = rec.get("abs_path") or rec.get("file_name")
                        if not imgp:
                            # maybe fn is path like
                            try:
                                pth = Path(str(fn))
                                if pth.exists():
                                    imgp = str(pth)
                            except Exception:
                                imgp = None
                        if imgp:
                            buf = _make_thumbnail_bytes(str(imgp))
                            if buf:
                                thumbs.append((buf, str(imgp)))
                    if thumbs:
                        break
    except Exception:
        logger.debug("thumbnail collection failed for feature %s", name, exc_info=True)

    if thumbs:
        story.append(Paragraph("Sample evidence", styles["Heading4"]))
        # display in rows, three per row
        row_cells = []
        for i, (buf, pth) in enumerate(thumbs):
            try:
                img = RLImage(buf, width=55 * mm, height=38 * mm)
                cap = Paragraph(Path(pth).name, ParagraphStyle("cap", parent=styles["Normal"], fontSize=8, alignment=TA_CENTER))
                t = Table([[img], [cap]], colWidths=[60 * mm])
                t.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
                row_cells.append(t)
            except Exception:
                continue
            if (i + 1) % 3 == 0 or i == len(thumbs) - 1:
                story.append(Table([row_cells], colWidths=[60 * mm] * len(row_cells)))
                story.append(Spacer(1, 2 * mm))
                row_cells = []

    # recommendations heuristics
    recs = []
    try:
        if isinstance(safe_out, dict):
            if safe_out.get("status") == "error":
                recs.append("Feature failed. Inspect logs and rerun the feature.")
            # domain specific heuristics
            if safe_out.get("mean_annotation_fraction") and float(safe_out.get("mean_annotation_fraction")) < 0.01:
                recs.append("Images contain little annotated area. Consider filtering background images.")
            if safe_out.get("border_touch_fraction") and float(safe_out.get("border_touch_fraction")) > 0.05:
                recs.append("Many boxes touch image borders. Consider re annotating clipped objects.")
    except Exception:
        recs.append("Could not compute automatic recommendations for this feature.")

    story.append(Paragraph("Recommendations", styles["Heading4"]))
    if recs:
        for r in recs:
            story.append(Paragraph("• " + r, styles["Normal"]))
    else:
        story.append(Paragraph("No automated recommendations generated for this feature", styles["Normal"]))

    story.append(PageBreak())


def _write_minimal_error_pdf(out_path: str, errors: List[str]):
    """
    Attempt to write a small fallback PDF that contains the error messages
    so the user can see what went wrong.
    """
    try:
        doc = SimpleDocTemplate(out_path, pagesize=A4, rightMargin=18 * mm, leftMargin=18 * mm)
        styles = getSampleStyleSheet()
        story = []
        story.append(Paragraph("CVEDA Report Generation Error", styles["Title"]))
        story.append(Spacer(1, 4 * mm))
        story.append(Paragraph("The detailed report failed to render. Below are error details captured during the attempt", styles["Normal"]))
        story.append(Spacer(1, 4 * mm))
        for e in errors:
            story.append(Paragraph(f"<pre>{e}</pre>", ParagraphStyle("err", parent=styles["Code"], fontSize=8)))
            story.append(Spacer(1, 2 * mm))
        doc.build(story)
        return True
    except Exception:
        try:
            # last resort write a tiny text like PDF via reportlab minimal
            doc = SimpleDocTemplate(out_path, pagesize=A4)
            styles = getSampleStyleSheet()
            doc.build([Paragraph("CVEDA failed to write any report", styles["Normal"])])
            return True
        except Exception:
            return False


def generate_pdf_report(audit_result: Dict[str, Any], out_path: str, config: Optional[Dict[str, Any]] = None) -> str:
    """
    Generate a detailed PDF report from audit_result and return the file path.

    The function is defensive. If errors happen while composing the report
    it will attempt to write a minimal fallback PDF that contains error details.
    That ensures a file path is present when possible.
    """
    cfg = config or {}
    sample_thumbs = int(cfg.get("sample_thumbnails", 6))
    include_features = cfg.get("include_features", None)

    out_path = str(out_path)
    errors: List[str] = []

    try:
        doc = SimpleDocTemplate(out_path, pagesize=A4, rightMargin=18 * mm, leftMargin=18 * mm, topMargin=18 * mm, bottomMargin=18 * mm)
        styles = getSampleStyleSheet()
        # adjust styles small
        def _ensure_style(stylesheet, name, **kwargs):
            """
            If a style named `name` exists in the stylesheet, update its attributes.
            Otherwise add a new ParagraphStyle with the given kwargs.
            """
            try:
                if name in stylesheet:
                    s = stylesheet[name]
                    # set attributes provided in kwargs
                    for k, v in kwargs.items():
                        # some kwargs such as 'parent' expect a style object
                        setattr(s, k, v)
                else:
                    stylesheet.add(ParagraphStyle(name, **kwargs))
            except Exception:
                # best effort fallback, do not raise style errors
                logger.debug("Style creation/update failed for %s", name, exc_info=True)

        # replace direct adds with safe ensures
        _ensure_style(styles, "Small", parent=styles["Normal"], fontSize=9)
        _ensure_style(styles, "Heading2", parent=styles["Heading1"], fontSize=16)
        _ensure_style(styles, "Heading3", parent=styles["Heading2"], fontSize=12)
        _ensure_style(styles, "Heading4", parent=styles["Normal"], fontSize=11)


        story: List[Any] = []

        # cover
        dataset_root = audit_result.get("index_root") or audit_result.get("dataset_root") or audit_result.get("index", {}) and "dataset"
        run_meta = {
            "Features run": len(audit_result.get("features", {})),
            "Checks": ", ".join(list(audit_result.get("checks", {}).keys())) if isinstance(audit_result.get("checks", {}), dict) else ""
        }
        try:
            _render_cover(story, styles, dataset_root or "dataset", run_meta)
        except Exception as e:
            errors.append("cover render failure " + traceback.format_exc())

        # executive
        try:
            _render_executive(story, styles, audit_result)
        except Exception as e:
            errors.append("executive render failure " + traceback.format_exc())

        # per feature
        features = audit_result.get("features", {}) or {}
        items = list(features.items())
        if include_features:
            items = [it for it in items if it[0] in include_features]

        if not items:
            story.append(Paragraph("No feature outputs available", styles["Normal"]))
        for name, out in items:
            try:
                _render_feature(story, styles, name, out or {}, audit_result.get("index", {}), sample_thumbs)
            except Exception:
                errors.append(f"feature {name} render failure\n" + traceback.format_exc())

        # final notes page
        try:
            story.append(Paragraph("Notes and next steps", styles["Heading2"]))
            story.append(Paragraph("This report was generated by CVEDA. Review feature sections to see detailed evidence and recommendations.", styles["Normal"]))
            story.append(PageBreak())
        except Exception:
            errors.append("final notes render failure " + traceback.format_exc())

        # attempt to build the PDF
        try:
            doc.build(story)
            # success
            return out_path
        except Exception as e:
            errors.append("doc build failure\n" + traceback.format_exc())
            logger.exception("PDF build failed", exc_info=True)
            # try to write minimal error pdf
            wrote = _write_minimal_error_pdf(out_path, errors)
            if wrote:
                return out_path
            # if fallback also failed raise final exception
            raise RuntimeError("Failed to write PDF report and fallback failed, see logs")
    except Exception as final_e:
        logger.exception("generate_pdf_report final failure", exc_info=True)
        # try to ensure a minimal fallback file exists
        try:
            _write_minimal_error_pdf(out_path, errors + [traceback.format_exc()])
            return out_path
        except Exception:
            # as last resort re raise
            raise final_e
