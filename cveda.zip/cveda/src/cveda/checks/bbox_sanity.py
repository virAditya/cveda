"""
Bounding box sanity checks.

Functions here detect zero area boxes inverted boxes boxes outside
image bounds tiny boxes and boxes that cover most of the image.

The main entry point run_bbox_sanity_checks accepts the canonical index
and returns a structured dictionary with categories of issues.
"""

from typing import Dict, Any, List
from ..annotations import clamp_bbox_to_image, is_bbox_inverted, swap_inverted_bbox, bbox_area


def find_zero_area_boxes(index: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Find annotations with zero area.

    Returns list of dict items with keys:
    - file_name
    - ann_index
    - bbox
    """
    res = []
    for fname, rec in index.items():
        for i, ann in enumerate(rec.get("annotations", [])):
            if bbox_area(ann["bbox"]) == 0.0:
                res.append({"file_name": fname, "ann_index": i, "bbox": ann["bbox"]})
    return res


def find_inverted_boxes(index: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Find annotations with inverted coordinates.

    Returns list of dict with file_name ann_index and bbox.
    """
    res = []
    for fname, rec in index.items():
        for i, ann in enumerate(rec.get("annotations", [])):
            if is_bbox_inverted(ann["bbox"]):
                res.append({"file_name": fname, "ann_index": i, "bbox": ann["bbox"]})
    return res


def find_boxes_outside_bounds(index: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Find boxes that lie partially or fully outside the image bounds.

    Returns file level entries with count and sample ann indices.
    """
    res = []
    for fname, rec in index.items():
        w = rec.get("width")
        h = rec.get("height")
        if not w or not h:
            continue
        outside = []
        for i, ann in enumerate(rec.get("annotations", [])):
            xmin, ymin, xmax, ymax = ann["bbox"]
            if xmin < 0 or ymin < 0 or xmax > w or ymax > h:
                outside.append({"ann_index": i, "bbox": ann["bbox"]})
        if outside:
            res.append({"file_name": fname, "outside_count": len(outside), "samples": outside[:5]})
    return res


def find_tiny_boxes(index: Dict[str, Any], min_relative: float = 1e-5, min_pixels: int = 16) -> List[Dict[str, Any]]:
    """
    Find boxes that are extremely small either in absolute pixels or relative area.

    Parameters
    index canonical dataset index
    min_relative float relative area threshold compared to image area
    min_pixels int absolute pixel threshold for area

    Returns list of dicts with file_name ann_index area and relative_area
    """
    results = []
    for fname, rec in index.items():
        w = rec.get("width")
        h = rec.get("height")
        if not w or not h:
            continue
        img_area = float(w) * float(h)
        for i, ann in enumerate(rec.get("annotations", [])):
            area = bbox_area(ann["bbox"])
            rel = area / img_area if img_area > 0 else 0.0
            if area <= min_pixels or rel <= min_relative:
                results.append({"file_name": fname, "ann_index": i, "area": area, "relative_area": rel})
    return results


def find_boxes_covering_image(index: Dict[str, Any], threshold: float = 0.9) -> List[Dict[str, Any]]:
    """
    Find boxes that cover more than threshold fraction of image area.

    Returns list of dict with file_name ann_index area and relative_area
    """
    res = []
    for fname, rec in index.items():
        w = rec.get("width")
        h = rec.get("height")
        if not w or not h:
            continue
        img_area = float(w) * float(h)
        for i, ann in enumerate(rec.get("annotations", [])):
            area = bbox_area(ann["bbox"])
            rel = area / img_area if img_area > 0 else 0.0
            if rel >= threshold:
                res.append({"file_name": fname, "ann_index": i, "area": area, "relative_area": rel})
    return res


def run_bbox_sanity_checks(index: Dict[str, Any], cfg: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Run the set of bbox sanity checks and return a structured summary.

    cfg optional dict with keys:
    - min_relative
    - min_pixels
    - covering_threshold

    The return format:
    {
        "zero_area": [...],
        "inverted": [...],
        "outside_bounds": [...],
        "tiny": [...],
        "covering_image": [...],
        "suggested_fixes": {...}
    }
    """
    cfg = cfg or {}
    min_relative = cfg.get("min_relative", 1e-5)
    min_pixels = cfg.get("min_pixels", 16)
    covering_threshold = cfg.get("covering_threshold", 0.9)

    zero_area = find_zero_area_boxes(index)
    inverted = find_inverted_boxes(index)
    outside = find_boxes_outside_bounds(index)
    tiny = find_tiny_boxes(index, min_relative=min_relative, min_pixels=min_pixels)
    covering = find_boxes_covering_image(index, threshold=covering_threshold)

    suggested_fixes = {
        "swap_inverted_supported": True,
        "clamp_outside_supported": True,
        "drop_zero_area_supported": True
    }

    return {
        "zero_area": zero_area,
        "inverted": inverted,
        "outside_bounds": outside,
        "tiny": tiny,
        "covering_image": covering,
        "suggested_fixes": suggested_fixes
    }
