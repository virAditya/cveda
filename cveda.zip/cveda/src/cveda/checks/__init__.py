"""
Checks package init.
"""

