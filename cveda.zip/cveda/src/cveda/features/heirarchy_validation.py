"""
hierarchy_validation

Validate user-provided hierarchies of classes. Config expected:
config["hierarchy"] = { "parent_class": ["child1","child2"], ... }

The check flags images where a child appears but parent does not.
"""

from typing import Dict, Any, List

def run_hierarchy_validation(index: Dict[str, Any], config: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    config:
      - hierarchy: dict mapping parent->list(child)
      - sample_limit: int

    Returns:
      {
        "feature": "hierarchy_validation",
        "violations": [ {"parent":P,"child":C,"file":fname} ],
        "status": "ok" or "no_hierarchy"
      }
    """
    cfg = config or {}
    hierarchy = cfg.get("hierarchy")
    sample_limit = int(cfg.get("sample_limit", 20))
    if not hierarchy:
        return {"feature": "hierarchy_validation", "status": "no_hierarchy", "message": "No hierarchy provided in config"}

    violations = []
    for fname, rec in (index or {}).items():
        classes = {str(ann.get("class","")) for ann in (rec.get("annotations", []) or [])}
        for parent, children in hierarchy.items():
            for child in children:
                if child in classes and parent not in classes:
                    if len(violations) < sample_limit:
                        violations.append({"parent": parent, "child": child, "file": fname})

    return {"feature": "hierarchy_validation", "violations": violations, "status": "ok"}
