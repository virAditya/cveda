"""
cveda package initializer.

Exports the primary public API class CVEDA.
"""

from .api import CVEDA

__all__ = ["CVEDA"]
__version__ = "0.1.0"
